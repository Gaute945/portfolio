from turtle import *

speed(1)
shape("turtle")


def Triangle():
    forward(120)
    right(120)
    forward(120)
    right(120)
    forward(120)

Triangle()